package com.bloodbank.repo;

import org.springframework.data.jpa.repository.JpaRepository;


import com.bloodbank.model.AcceptReview;

public interface AcceptReviewRespository extends JpaRepository<AcceptReview, Integer>{

}
