import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homebase',
  templateUrl: './homebase.component.html',
  styleUrls: ['./homebase.component.css']
})
export class HomebaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
