import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userreciver',
  templateUrl: './userreciver.component.html',
  styleUrls: ['./userreciver.component.css']
})
export class UserreciverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
