import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home2',
  templateUrl: './home-component2.component.html',
  styleUrls: ['./home-component2.component.css']
})
export class HomeComponent2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
