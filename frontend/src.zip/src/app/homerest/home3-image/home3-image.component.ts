import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home3',
  templateUrl: './home3-image.component.html',
  styleUrls: ['./home3-image.component.css']
})
export class Home3ImageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
