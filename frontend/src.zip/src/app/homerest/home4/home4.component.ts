import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home4',
  templateUrl: './home4.component.html',
  styleUrls: ['./home4.component.css']
})
export class Home4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
